<h1>Link do projeto <a href="https://italomirandasantiago.github.io/site-simples-de-inscricao-para-um-evento/">click</a.</h1>

<h2>feito apenas para treinar CSS</h2>
